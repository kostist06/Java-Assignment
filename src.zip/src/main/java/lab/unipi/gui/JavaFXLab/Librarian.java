package lab.unipi.gui.JavaFXLab;

public class Librarian extends User {
	
	private String tmhma_ergasias;
    private String education_level;

    public Librarian(int code , String name , String surname , String birth_date , String phone , String email , String tmhma_ergasias , String education_level) {

        super(code, name, surname, birth_date, phone, email);
        this.tmhma_ergasias = tmhma_ergasias;
        this.education_level = education_level;
    }

    //Getters & setters
    public String getTmhma_Ergasias() {

        return tmhma_ergasias;
    }

    public void setTmhma_Ergasias(String tmhma_ergasias){

        this.tmhma_ergasias = tmhma_ergasias;
    }

    public String getEducation_Level() {

        return education_level;
    }

    public void setEducation_Level(String education_level){

        this.education_level = education_level;
    }
}
