package lab.unipi.gui.JavaFXLab.scenes;




import java.util.List;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import lab.unipi.gui.JavaFXLab.App;
import lab.unipi.gui.JavaFXLab.Book;
import javafx.scene.control.TableColumn;

public class BookSceneCreator extends SceneCreator implements EventHandler<MouseEvent>{
	
	//Δήλωση TableView
	private TableView<Book> bookTableView;
   
	//Δήλωση TextFields
    private TextField isbnField, titleField, authorField, publisherField, yearField, categoryField, availabilityField;
    
    //Δήλωση Buttons
    private Button newBookBtn, updateBookBtn, deleteBookBtn, backBtn;

    //Δήλωση GridPanes
    private GridPane inputFieldsPane, rootGridPane;
    
    //Δήλωση Flowpane
    private FlowPane buttonFlowPane;
    
    public BookSceneCreator(double width, double height) {
    	super(width, height);
    	
    	 bookTableView = new TableView<>();
         
    	
         
    	//Στήλες του πίνακα βιβλίων
    	TableColumn<Book, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("isbn"));

        TableColumn<Book, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("title"));
        
        TableColumn<Book, String> authorCol = new TableColumn<>("Author");
        authorCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("author"));
        
        TableColumn<Book, String> publisherCol = new TableColumn<>("Publisher");
        publisherCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("publisher"));
        
        TableColumn<Book, Integer> yearCol = new TableColumn<>("Year");
        yearCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("year"));
        
        TableColumn<Book, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("category"));
        
        TableColumn<Book, String> availabilityCol = new TableColumn<>("Availability");
        availabilityCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("availability"));
        
        //προσθήκη στηλών στο TableView
        bookTableView.getColumns().addAll(titleCol, authorCol, isbnCol, publisherCol, yearCol, categoryCol, availabilityCol);
        
        
        // Δημιουργία GridPane 
        inputFieldsPane = new GridPane();
        inputFieldsPane.setHgap(10);
        inputFieldsPane.setVgap(10);
        
        // Δημιουργία TextFields
        isbnField = new TextField(); isbnField.setPromptText("ISBN");
        titleField = new TextField(); titleField.setPromptText("Title");
        authorField = new TextField(); authorField.setPromptText("Author");
        isbnField = new TextField(); isbnField.setPromptText("ISBN");
        publisherField = new TextField(); publisherField.setPromptText("Publisher");
        yearField = new TextField(); yearField.setPromptText("Year");
        categoryField = new TextField(); categoryField.setPromptText("Category");
        availabilityField = new TextField(); availabilityField.setPromptText("Availability");
        
        // Root layout
        rootGridPane = new GridPane();
        rootGridPane.setHgap(10);
        rootGridPane.setVgap(10);
        
        //Δημιουργία κουμπιών λειτουργιών
        newBookBtn = new Button("New Book");
        updateBookBtn = new Button("Update");
        deleteBookBtn = new Button("Delete");
        backBtn = new Button("Back");
        
        
        // Προσθήκη των πεδίων εισαγωγής στο inputFieldsPane
        inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.add(new Label("Title:"), 0, 0);
        inputFieldsPane.add(titleField, 1, 0);
        inputFieldsPane.add(new Label("Author:"), 0, 1);
        inputFieldsPane.add(authorField, 1, 1);
        inputFieldsPane.add(new Label("ISBN:"), 0, 2);
        inputFieldsPane.add(isbnField, 1, 2);
        inputFieldsPane.add(new Label("Publisher"), 0, 3);
        inputFieldsPane.add(publisherField, 1, 3);
        inputFieldsPane.add(new Label("Year"), 0, 4);
        inputFieldsPane.add(yearField, 1, 4);
        inputFieldsPane.add(new Label("Category"), 0, 5);
        inputFieldsPane.add(categoryField, 1, 5);
        inputFieldsPane.add(new Label("Availability"), 0, 6);
        inputFieldsPane.add(availabilityField, 1, 6);
        
        // Pane για τα κουμπιά	
        buttonFlowPane = new FlowPane(10, 10);
        buttonFlowPane.setHgap(10);
        buttonFlowPane.getChildren().addAll(newBookBtn, updateBookBtn, deleteBookBtn, backBtn);
        
        
        // Προσθήκη στοιχείων στο rootGridPane
        rootGridPane.add(bookTableView, 0, 0);         
        rootGridPane.add(inputFieldsPane, 1, 0);             
        rootGridPane.add(buttonFlowPane, 0, 2);
        
        
        // Σύνδεση κουμπιών με event handler
        newBookBtn.setOnMouseClicked(this);
        updateBookBtn.setOnMouseClicked(this);
        deleteBookBtn.setOnMouseClicked(this);
        backBtn.setOnMouseClicked(this);
        bookTableView.setOnMouseClicked(this);
        tableSync();
    }
    
    // Δημιουργία και επιστροφή της σκηνής με το root layout
    public Scene createScene() {
        return new Scene(rootGridPane, width, height);
    }
    
    //Διαχείρση περιπτώσεων για κάθε button
    public void handle(MouseEvent event) {
    	try {
    		//Button newBook
    		if (event.getSource() == newBookBtn) {
    			
    			// Ανάγνωση τιμών από τα Fields
    			String isbn = isbnField.getText();
    			String title = titleField.getText();
    			String author = authorField.getText();
    			String publisher = publisherField.getText();
    			int year = Integer.parseInt(yearField.getText());
    			String category = categoryField.getText();
    			String availabilityText = availabilityField.getText();
    			
    			boolean availability;
    			
    			// Έλεγχος εγκυρότητας για το πεδίο availability
    			if (availabilityText.equalsIgnoreCase("true") || availabilityText.equalsIgnoreCase("false")) {
                    availability = Boolean.parseBoolean(availabilityText);
                } else {
                    showAlert("Σφάλμα", "Το πεδίο 'Availability' πρέπει να είναι 'true' ή 'false'.");
                    return;
                }
    			
    			// Δημιουργία νέου βιβλίου
    			createBook(isbn, title, author, publisher, year, category, availability);
    			tableSync();
    			clearTextFields();
    		
    			//Button Update Book
    		} else if (event.getSource() == updateBookBtn) {
            
    			// Ανάγνωση τιμών από τα Fields
    			String isbn = isbnField.getText();
    			String title = titleField.getText();
    			String author = authorField.getText();
    			String publisher = publisherField.getText();
    			String year = yearField.getText();
    			String category = categoryField.getText();
    			String availabilityText = availabilityField.getText();
    			
    			boolean availability;
    			if (availabilityText.equalsIgnoreCase("true") || availabilityText.equalsIgnoreCase("false")) {
                    availability = Boolean.parseBoolean(availabilityText);
                } else {
                    showAlert("Σφάλμα", "Το πεδίο 'Availability' πρέπει να είναι 'true' ή 'false'.");
                    return;
                }
    			
    			// Ενημέρωση βιβλίου
    			updateBook(isbn, title, author, publisher, Integer.parseInt(year), category, availability);
    			tableSync();
    			clearTextFields();
        
    		//Button delete Book	
    		} else if (event.getSource() == deleteBookBtn) {
    			deleteBook(isbnField.getText()); //καλεσμα συνάρτησης για την διαγραφή
    			tableSync();
    			clearTextFields();
    			
        	//button back
    		} else if (event.getSource() == backBtn) {
    			App.primaryStage.setScene(App.mainScene);
    			App.primaryStage.setTitle("Main Window");
    		}
    	}catch (NumberFormatException e) {
    		// Αν το έτος δεν είναι έγκυρος αριθμός
    		showAlert("Invalid input", "Year must be a valid integer.");
    	}
    }
    
 // Δημιουργεί νέο αντικείμενο Book και το προσθέτει στη λίστα των βιβλίων
    public void createBook(String isbn, String title, String author, String publisher, int year, String category, boolean availability) {
    	Book newBook = new Book(isbn, title, author, publisher, year, category, availability);
    	App.books.add(newBook);
    }
    
 // Καθαρίζει όλα τα fields
    public void clearTextFields() {
    	isbnField.setText("");
    	titleField.setText("");
    	authorField.setText("");
    	publisherField.setText("");
    	yearField.setText("");
    	categoryField.setText("");
    	availabilityField.setText("");
    }
    
    public void tableSync() {
    	List<Book> items = bookTableView.getItems();
        items.clear();

         for(Book newBook : App.books) {

             if(newBook instanceof Book) {

                 items.add((Book) newBook);

             }
         }
    }
    
 // Ενημερώνει τα στοιχεία του βιβλίου με βάση ISBN
    public void updateBook(String isbn, String title, String author, String publisher, int year, String category, boolean availability) {
    	
    	for(Book newbook : App.books) {
    		if((newbook.getIsbn()).equals(isbn)) {
    			newbook.setTitle(title);
    			newbook.setAuthor(author);
    			newbook.setPublisher(publisher);
    			newbook.setYear(year);
    			newbook.setCategory(category);
    			newbook.setAvailability(availability);
    			break;
    		}
    	}
    	
    }
    
 // Διαγράφει το βιβλίο με το δοσμένο ISBN από τη λίστα
    public void deleteBook(String isbn) {
    	for (int i =0; i < App.books.size(); i++) {
    		if(App.books.get(i).getIsbn().equals(isbn)) {
    			App.books.remove(i);
    			break;
    		}
    	}
    }
    
    
 // Εμφανίζει ένα παράθυρο με μήνυμα σφάλματος
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    

}
