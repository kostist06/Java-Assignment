package lab.unipi.gui.JavaFXLab.scenes;


import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import lab.unipi.gui.JavaFXLab.App;
import lab.unipi.gui.JavaFXLab.Loan;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import lab.unipi.gui.JavaFXLab.*;
import java.util.ArrayList;
import java.util.List;

public class LoanSceneCreator extends SceneCreator implements EventHandler<MouseEvent>{
	
	// Δήλωση πινάκων για φοιτητές, βιβλία και δανεισμούς
	private TableView<Student> studentTable;
	private TableView<Book> bookTable;
	private TableView<Loan> loanTable;
	
	// Δήλωση κουμπιών για λειτουργίες δανεισμών
	private Button newLoanBtn, returnBookBtn, backBtn, searchStudentBtn, searchBookBtn, clearStudentBtn, clearBookBtn, showActiveLoansBtn, showOverdueLoansBtn, showCompletedLoansBtn, clearLoanFilterBtn;
	
	//Δήλωση gridPane FlowPane
	private GridPane rootGridPane;
	private FlowPane buttonFlowPane;
	
	private TextField studentSearchField;
	private TextField bookSearchField;
	
	// Μετρητής για μοναδικό ID δανεισμού
	private int loanIdCounter = 1;
	
	public LoanSceneCreator(double width, double height) {
		super(width, height);
		
		// Αρχικοποίηση πινάκων
		studentTable = new TableView<>();
		bookTable = new TableView<>();
		loanTable = new TableView<>();
		
		
		// Ορισμός στηλών πίνακα φοιτητών
		TableColumn<Student, Integer> amCol = new TableColumn<>("Am");
		amCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("am"));
		
		TableColumn<Student, String> nameCol = new TableColumn<>("Name");
		nameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("Name"));
		
		TableColumn<Student, String> surnameCol = new TableColumn<>("Surname");
		surnameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("surname"));
		
		TableColumn<Student, String> departmentCol = new TableColumn<>("Department");
		departmentCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("department"));
		
		studentTable.getColumns().addAll(amCol, nameCol, surnameCol, departmentCol);
		
		
		// Ορισμός στηλών πίνακα βιβλίων
		TableColumn<Book, String> isbnCol = new TableColumn<>("ISBN");
		isbnCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("isbn"));
		
		TableColumn<Book, String> titleCol = new TableColumn<>("Title");
		titleCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("title"));
		
		bookTable.getColumns().addAll(isbnCol, titleCol);
		
		
		// Ορισμός στηλών πίνακα δανεισμών
		TableColumn<Loan, Integer> loanidCol = new TableColumn<>("Loan ID");
		loanidCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("loanId"));
		
		TableColumn<Loan, String> studentCol = new TableColumn<>("Student");
		studentCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("studentName"));
		
		TableColumn<Loan, String> bookCol = new TableColumn< >("Book");
        bookCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("bookTitle"));

        TableColumn<Loan, String> loanDateCol = new TableColumn<>("Loan Date");
        loanDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("loanDate"));

        TableColumn<Loan, String> dueDateCol = new TableColumn<>("Due Date");
        dueDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("dueDate"));

        TableColumn<Loan, String> returnDateCol = new TableColumn<>("Return Date");
        returnDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("returnDate"));

		
        loanTable.getColumns().addAll(loanidCol, studentCol, bookCol, loanDateCol, dueDateCol, returnDateCol);

        // Ορισμός fields
        studentSearchField = new TextField();
        studentSearchField.setPromptText("Search student by AM, name, or department");
        
        bookSearchField = new TextField();
        bookSearchField.setPromptText("Search book by title, author, ISBN, category or availability");
		
        // Ορισμός buttons 
		newLoanBtn = new Button("New Loan");
        returnBookBtn = new Button("Return Book");
        backBtn = new Button("Back");
        searchStudentBtn = new Button("Search Students");
        searchBookBtn = new Button("Search Books");
        clearStudentBtn = new Button("Clear Student Filter");
        clearBookBtn = new Button("Clear Book Filter");
        showActiveLoansBtn = new Button("Active Loans");
        showOverdueLoansBtn = new Button("Overdue Loans");
        showCompletedLoansBtn = new Button("Completed Loans");
        clearLoanFilterBtn = new Button("Clear Loan Filter");
        
     // Ορισμός των handlers για όλα τα κουμπιά
        newLoanBtn.setOnMouseClicked(this);
        returnBookBtn.setOnMouseClicked(this);
        backBtn.setOnMouseClicked(this);
        searchStudentBtn.setOnMouseClicked(this);
        searchBookBtn.setOnMouseClicked(this);
        clearStudentBtn.setOnMouseClicked(this);
        clearBookBtn.setOnMouseClicked(this);
        showActiveLoansBtn.setOnMouseClicked(this);
        showOverdueLoansBtn.setOnMouseClicked(this);
        showCompletedLoansBtn.setOnMouseClicked(this);
        clearLoanFilterBtn.setOnMouseClicked(this);
        
     // Τοποθέτηση βασικών κουμπιών σε FlowPane
        buttonFlowPane = new FlowPane(10, 10);
        buttonFlowPane.getChildren().addAll(newLoanBtn, returnBookBtn, backBtn);
        
        rootGridPane = new GridPane();
        
     // Πίνακας φοιτητών
        rootGridPane.add(new Label("Students:"), 0, 0);
        rootGridPane.add(studentTable, 0, 3, 1, 2);

     // Πίνακας βιβλίων
        rootGridPane.add(new Label("Books:"), 1, 0);
        rootGridPane.add(bookTable, 1, 3, 1, 1);

     // Πίνακας δανεισμών
        rootGridPane.add(new Label("Loans:"), 0, 5);
        rootGridPane.add(loanTable, 0, 6, 2, 1); 

     // Κουμπιά λειτουργιών
        rootGridPane.add(buttonFlowPane, 0, 7, 2, 1); 
     // Πεδία και κουμπιά αναζήτησης
        rootGridPane.add(studentSearchField, 0, 1);
        rootGridPane.add(searchStudentBtn, 0, 2);
        rootGridPane.add(bookSearchField, 1, 1);
        rootGridPane.add(searchBookBtn, 1, 2);
        rootGridPane.add(clearStudentBtn, 2, 1); 
        rootGridPane.add(clearBookBtn, 2, 2);
     // Φίλτρα δανεισμών
        rootGridPane.add(showActiveLoansBtn, 2, 4);
        rootGridPane.add(showOverdueLoansBtn, 2, 5);
        rootGridPane.add(showCompletedLoansBtn, 2, 6);
        rootGridPane.add(clearLoanFilterBtn, 2, 7);
        rootGridPane.setHgap(5);
        rootGridPane.setVgap(0);
        tableSync();

	}
	// δημιουργεί και επιστρέφει το τελικό Scene
	public Scene createScene() {
        return new Scene(rootGridPane, width, height);
    }
	
	//χειρισμός των ενεργειών
	public void handle(MouseEvent event) {
		
		// Δημιουργία νέου δανεισμού
		if (event.getSource() == newLoanBtn) {
			Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
			Book selectedBook = bookTable.getSelectionModel().getSelectedItem();
			
			if (selectedStudent != null && selectedBook != null && selectedBook.getAvailability() && selectedStudent.getMax_books_to_loan() > 0) {
				Loan newLoan = new Loan(loanIdCounter++, selectedStudent, selectedBook);
				selectedBook.setAvailability(false);
				selectedStudent.setMax_books_to_loan(selectedStudent.getMax_books_to_loan() - 1);
				App.loans.add(newLoan);
				tableSync();
				
			}
			
		// Επιστροφή βιβλίου	
		} else if (event.getSource() == returnBookBtn) {
			Loan selectedLoan = loanTable.getSelectionModel().getSelectedItem();
			
			if(selectedLoan != null && selectedLoan.getReturnDate() == null) {
				selectedLoan.updatedelay(java.time.LocalDate.now());
				selectedLoan.getBook().setAvailability(true);
				selectedLoan.getStudent().setMax_books_to_loan(selectedLoan.getStudent().getMax_books_to_loan() + 1);
				
				// Αν υπάρχει καθυστέρηση, δημιουργείται πρόστιμο
				if(selectedLoan.getDelay()) {
					Fine fine = new Fine(App.fines.size() + 1, selectedLoan);
					App.fines.add(fine);
					
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
		            alert.setTitle("Καθυστέρηση");
		            alert.setHeaderText("Το βιβλίο επιστράφηκε καθυστερημένα.");
		            alert.setContentText("Πρόστιμο: " + fine.getFineAmount() + "€");
		            alert.showAndWait();
				}
				tableSync();
			}
			
		// Επιστροφή στην κεντρική σκηνή
		} else if (event.getSource() == backBtn) {
			App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Main Window");
		
           // Αναζήτηση φοιτητή
		} else if (event.getSource() == searchStudentBtn) {
			String search = studentSearchField.getText().toLowerCase().trim();
			studentTable.getItems().clear();
			
			for (Student s : App.students) {
				if (s.getAm().toLowerCase().contains(search) || s.getName().toLowerCase().contains(search) || s.getSurname().toLowerCase().contains(search) || s.getDepartment().toLowerCase().contains(search)) {
					
					studentTable.getItems().add(s);
				}
			} 
			
		  // Αναζήτηση βιβλίου	
		} else if (event.getSource() == searchBookBtn) {
			
			String search = bookSearchField.getText().toLowerCase().trim();
			bookTable.getItems().clear();
			
			for (Book b : App.books) {
				if (b.getTitle().toLowerCase().contains(search) || b.getAuthor().toLowerCase().contains(search) ||
						b.getIsbn().toLowerCase().contains(search) || b.getCategory().toLowerCase().contains(search) ) {
					
					bookTable.getItems().add(b);
				}
			}
			
			
			// Εκκαθάριση φοιτητών	
		}else if (event.getSource() == clearStudentBtn ) {
			
			studentSearchField.clear();
			studentTable.getItems().clear();
			studentTable.getItems().addAll(App.students);
		
			// Εκκαθάριση βιβλίων
		} else if (event.getSource() == clearBookBtn) {
			bookSearchField.clear();
			bookTable.getItems().clear();
			for (Book b : App.books) {
			    if (b.getAvailability()) {
			        bookTable.getItems().add(b);
			    }
			}
			
			// Προβολή ενεργών δανείων
		}else if (event.getSource() == showActiveLoansBtn) {
		    loanTable.getItems().clear();
		    for (Loan loan : App.loans) {
		        if (loan.getReturnDate() == null) {
		            loanTable.getItems().add(loan);
		        }
		    }
		    
		 // Προβολή εκπρόθεσμων δανείων
		}else if (event.getSource() == showOverdueLoansBtn) {
		    loanTable.getItems().clear();
		    java.time.LocalDate today = java.time.LocalDate.now();
		    for (Loan loan : App.loans) {
		        if (loan.getReturnDate() == null && loan.getDueDate().isBefore(today)) {
		            loanTable.getItems().add(loan);
		        }
		    }
		    
		 // Προβολή ολοκληρωμένων δανείων
		}else if (event.getSource() == showCompletedLoansBtn) {
		    loanTable.getItems().clear();
		    for (Loan loan : App.loans) {
		        if (loan.getReturnDate() != null) {
		            loanTable.getItems().add(loan);
		        }
		    }
		    
		    // Καθαρισμός φίλτρων δανεισμών
		}else if (event.getSource() == clearLoanFilterBtn) {
		    loanTable.getItems().clear();
		    loanTable.getItems().addAll(App.loans);
		}

 		
	}
	
	//Μέθοδος συγχρονισμού όλων των πινάκων
	private void tableSync() {
		studentTable.getItems().clear();
		bookTable.getItems().clear();
	    loanTable.getItems().clear();

	    studentTable.getItems().addAll(App.students);
	    for (Book b : App.books) {
	        if (b.getAvailability()) {
	            bookTable.getItems().add(b);
	        }
	    }
	    loanTable.getItems().addAll(App.loans);
	}

}
