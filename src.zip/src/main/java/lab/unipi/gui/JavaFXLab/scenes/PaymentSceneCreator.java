package lab.unipi.gui.JavaFXLab.scenes;

import java.util.ArrayList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import lab.unipi.gui.JavaFXLab.App;
import lab.unipi.gui.JavaFXLab.Fine;
import lab.unipi.gui.JavaFXLab.Student;
import java.util.List;

public class PaymentSceneCreator extends MainSceneCreator implements EventHandler<MouseEvent> {
	
	//Δήλωση Πινάκων
	private TableView<Student>studentTableView;
	private TableView<Fine>paymentHistoryTableView;
	
	//Δήλωση TextField και buttons
	private TextField fineCodeField;
	private Button pendingFinesBtn , finePaymentBtn , paymentHistoryBtn, backBtn;
 	
	//Δήλωση GridPane & FlowPane
	private GridPane inputFieldsPane , rootGridPane;
	private FlowPane buttonFlowPane;
	
	public PaymentSceneCreator(double width , double height){
		   
		    super(width , height);
		    
		    //Λιστα Δεδομενων
	 		studentTableView = new TableView<>();
	 		paymentHistoryTableView = new TableView<>();
	 		
	 		//Δημιουργία Columns για το StudentTableView
		    TableColumn<Student , Integer>codeCol = new TableColumn<>("Student Code");
	 	    codeCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("code"));
	 	    
	 	    TableColumn<Student, String> fineCodesCol = new TableColumn<>("Fine Code");
	 	    fineCodesCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("fineCodes"));
	 	    
	 	    TableColumn<Student , String>nameCol = new TableColumn<>("Name");
	 	    nameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));
	 	    
	 	    TableColumn<Student , String>surnameCol = new TableColumn<>("Surname");
	 	    surnameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("surname"));
	 	    
	 	    TableColumn<Student , String>phoneCol = new TableColumn<>("Phone");
	 	    phoneCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("phone"));
	 	    
	 	    TableColumn<Student , String>emailCol = new TableColumn<>("Email");
	 	    emailCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("email"));
	 	    
	 	    TableColumn<Student , String>amCol = new TableColumn<>("Am");
	 	    amCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("am"));
	 	    
	 	    studentTableView.getColumns().addAll(codeCol, fineCodesCol , nameCol , surnameCol , phoneCol ,  emailCol , amCol);
	 	    
	 	    
	 	 //Δημιουργία Columns για το paymentHistoryTableView
	 	    TableColumn<Fine , Integer>fineCodeCol = new TableColumn<>("FineCode");
	 	    fineCodeCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("fineCode"));
	 	    	
	 	    TableColumn<Fine , Boolean>paidCol = new TableColumn<>("Paid");
	 	    paidCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("paid"));
	 	    
	 	   TableColumn<Fine, Double> amountCol = new TableColumn<>("Amount");
	 	   amountCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("fineAmount"));
	 	    
		    paymentHistoryTableView.getColumns().addAll(fineCodeCol , paidCol, amountCol);
		    
		    
	 	    
		    fineCodeField = new TextField();
	        fineCodeField.setPromptText("Fine Code");

	        

	        inputFieldsPane = new GridPane();
	        inputFieldsPane.setHgap(10);
	        inputFieldsPane.setVgap(10);

	        inputFieldsPane.add(new Label("Fine Code:"), 0, 0);
	        inputFieldsPane.add(fineCodeField, 1, 0);
	        
	        

	        // Buttons
	        pendingFinesBtn = new Button("Pending Fines");
	        finePaymentBtn = new Button("Fine Payment");
	        paymentHistoryBtn = new Button("Payment History");
	        backBtn = new Button("Back");

	        pendingFinesBtn.setOnMouseClicked(this);
	        finePaymentBtn.setOnMouseClicked(this);
	        paymentHistoryBtn.setOnMouseClicked(this);
	        backBtn.setOnMouseClicked(this);

	        buttonFlowPane = new FlowPane(10, 10);
	        buttonFlowPane.getChildren().addAll(pendingFinesBtn, finePaymentBtn, paymentHistoryBtn, backBtn);

	        // Root layout
	        rootGridPane = new GridPane();
	        rootGridPane.setHgap(10);
	        rootGridPane.setVgap(10);

	        rootGridPane.add(new Label("Students with Fines:"), 0, 0);
	        rootGridPane.add(studentTableView, 0, 1);

	        rootGridPane.add(new Label("Payment History:"), 1, 0);
	        rootGridPane.add(paymentHistoryTableView, 1, 1);

	        rootGridPane.add(inputFieldsPane, 0, 2);
	        rootGridPane.add(buttonFlowPane, 0, 3, 2, 1);
	        

	 	    
	}
	// Δημιουργία σκηνής
 	public Scene createScene() { return new Scene(rootGridPane , width , height);
 	}
	
 	
 // Διαχείριση λειτουργιών των buttons
	public void handle(MouseEvent event) {
		
		
		if(event.getSource() == pendingFinesBtn) {

            showPendingFines();
        }
        else if(event.getSource() == finePaymentBtn) {

            setFinePaid();
        }
        else if(event.getSource() == paymentHistoryBtn) {

            showPaidFines();
        }
        else if(event.getSource() == backBtn) {

            App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Main Window");
        }
		
		
	}
	 // Συγχρονισμός πίνακα φοιτητών
	public void studentTableSync() {
 	    
 		//List<Student> items = studentTableView.getItems();
 		studentTableView.getItems().clear();
 		//items.clear();
 		
 		for(Student newStudent : App.students) {
 				studentTableView.getItems().add(newStudent);
 		}
 		
 	}
	
    // Συγχρονισμός πίνακα προστίμων
	public void fineTableSync() {
 		paymentHistoryTableView.getItems().clear();
 		for(Fine f : App.fines) {
 				paymentHistoryTableView.getItems().add(f);
 		}
	}
	
	// Εμφάνιση φοιτητών με εκκρεμή πρόστιμα
	public void showPendingFines() {
		
		studentTableView.getItems().clear();
	    
	    for (Fine fine : App.fines) {
	        if (!fine.getPaid()) {
	            Student student = fine.getLoan().getStudent();
	            if (!studentTableView.getItems().contains(student)) {
	                studentTableView.getItems().add(student);
	            }
	        }
	    }
	}
	
	 // Σημείωση προστίμου ως πληρωμένο
	public void setFinePaid() {

        try {

            int fineCode = Integer.parseInt(fineCodeField.getText().trim());

            boolean found = false;
            for (Fine fine : App.fines) {
                if (fine.getFineCode() == fineCode) {

                    fine.setPaid(true);
                    found = true;
                    break;
                }
            }

            if (found) {
            	// Ενημερωτικό Alert: επιτυχής καταχώρηση πληρωμής προστίμου
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("Το πρόστιμο καταχωρήθηκε ως πληρωμένο.");
                alert.showAndWait();

                studentTableSync();
                showPendingFines();

            } else {
            	// Προειδοποιητικό Alert: δεν βρέθηκε πρόστιμο με τον δοθέντα κωδικό
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Fine Not Found");
                alert.setHeaderText(null);
                alert.setContentText("Δεν βρέθηκε πρόστιμο με αυτόν τον κωδικό.");
                alert.showAndWait();
            }

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null);
            alert.setContentText("Παρακαλώ δώσε έγκυρο αριθμό κωδικού προστίμου.");
            alert.showAndWait();
        }
    }

	// Εμφάνιση πληρωμένων προστίμων
    public void showPaidFines() {

        paymentHistoryTableView.getItems().clear(); 

        for (Fine fine : App.fines) {
            if (fine.getPaid()) {
                paymentHistoryTableView.getItems().add(fine);
            }
        }
    }

	
   
	
	
	
	
}
