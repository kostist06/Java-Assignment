package lab.unipi.gui.JavaFXLab;


import java.time.temporal.ChronoUnit;

public class Fine implements FeePolicy {
	
	private int fineCode;
    private double fineAmount;
    private boolean paid;
    private Loan loan;

    public Fine(int finecode , Loan loan){

        this.fineCode = finecode;
        this.loan = loan;
        this.paid = false;

        long overdueDays = ChronoUnit.DAYS.between(loan.getDueDate(),loan.getReturnDate());

        if (overdueDays > 0) {
            this.fineAmount = calculateFine((int) overdueDays);
        } else {
            this.fineAmount = 0;
            this.paid = true; 
        }

    }

    public double calculateFine(int overdueDays) {
        if (overdueDays <= 10) {
            return overdueDays;
        } else {
            return 10;
        }
    }
    
    
    //Getters & setters
    public int getFineCode() {

        return fineCode;
    }

    public void setFineCode(int fineCode) {

        this.fineCode = fineCode;
    }

    public double getFineAmount() {

        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {

        this.fineAmount = fineAmount;
    }

    public boolean getPaid() {

        return paid;
    }

    public void setPaid(boolean paid) {

        this.paid = paid;
    }
    
    public Loan getLoan() {
    	return loan;
    }

}
