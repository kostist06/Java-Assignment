package lab.unipi.gui.JavaFXLab.scenes;


import javafx.scene.control.Button;
import lab.unipi.gui.JavaFXLab.App;
import javafx.scene.layout.FlowPane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;

public class MainSceneCreator extends SceneCreator implements EventHandler<MouseEvent>{
	
	FlowPane rootFlowPane;
	
	//Δήλωση κουμπιών
	private Button booksButton;
    private Button studentsButton;
    private Button loansButton;
    private Button fineButton;

    public MainSceneCreator(double width, double height) {
        super(width, height);
        
        rootFlowPane = new FlowPane();

     // Δημιουργία των κουμπιών για τις λειτουργίες
        booksButton = new Button("Book Management");
        studentsButton = new Button("Student Management");
        loansButton = new Button("Loan Management");
        fineButton = new Button("Fine Management");
        
        
     // Καθορισμός event handler για κάθε κουμπί
        booksButton.setOnMouseClicked(this);
        studentsButton.setOnMouseClicked(this);
        loansButton.setOnMouseClicked(this);
        fineButton.setOnMouseClicked(this);
        
        rootFlowPane.setHgap(10);
        rootFlowPane.setAlignment(Pos.CENTER);
        
     // Προσθήκη κουμπιών στο layout του rootFlowPane
        rootFlowPane.getChildren().add(booksButton);
        rootFlowPane.getChildren().add(studentsButton);
        rootFlowPane.getChildren().add(loansButton);
        rootFlowPane.getChildren().add(fineButton);
        
    }
    
    public Scene createScene() { return new Scene(rootFlowPane, width, height); }
    
    //Διαχείριση περιπτώσεων κουμπιών
    public void handle(MouseEvent event) {
    	
    	//μεταφορά στο Book Scene
    	if(event.getSource() == booksButton) {
    		App.primaryStage.setScene(App.bookScene);
    		App.primaryStage.setTitle("Book Management Window");
    		
    	//μεταφορά στο Student Scene
    	} else if(event.getSource() == studentsButton) {
    		App.primaryStage.setScene(App.studentScene);
    		App.primaryStage.setTitle("Student Management Window");
    		
    	//μεταφορά στο Loan Scene	
    	} else if(event.getSource() == loansButton) {
    		App.primaryStage.setScene(App.loanScene);
    		App.primaryStage.setTitle("Loans Management Window");
    	
    	//μεταφορά στο Fine Scene	
    	} else if(event.getSource() == fineButton) {
    		App.primaryStage.setScene(App.fineScene);
    		App.primaryStage.setTitle("Fine Management Window");
    	}
    }

}
