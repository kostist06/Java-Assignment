package lab.unipi.gui.JavaFXLab;

public class User {
	
	private String name;
	private String surname;
	private int code;
	private String birth_date;
	private String phone;
	private String email;
	
	public User(int code , String name , String surname , String birth_date , String phone , String email) {

        this.code = code;
        this.name = name;
        this.surname = surname;
        this.birth_date = birth_date;
        this.phone = phone;
        this.email = email;

    }

	//Getters & setters
    public int getCode() {

        return code;
    }

    public void setCode(int code) {

        this.code = code;
    }

    public String getName() {

        return name;
    }

    public void setName(String name){


        this.name = name;
    }

    public String getSurname() {

        return surname;

    }

    public void setSurname(String surname){


        this.surname = surname;
    }

    public String getBirth_date() {

        return birth_date;
    }

    public void setBirth_date(String birth_date){


        this.birth_date = birth_date;
    }

    public String getPhone() {

        return phone;
    }

    public void setPhone(String phone) {


        this.phone = phone;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {


        this.email = email;
    }

}
