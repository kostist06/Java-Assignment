package lab.unipi.gui.JavaFXLab;

import java.util.ArrayList;
import java.util.List;

public class Student extends User {
	
	private String am;
	private String department;
	private int max_books_to_loan = 5;
	
	public Student(int code , String name, String surname , String birth_date , String phone , String email, String am, String department, int max_books_to_loan) {
		super(code, name, surname, birth_date, phone, email);
		this.am = am;
		this.department = department;
		this.max_books_to_loan = max_books_to_loan;
	}
	
	//Getters & setters
	public String getAm() {
		return am;
	}
	
	public void setAm(String am) {
		this.am = am;
	}
	
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public int getMax_books_to_loan() {
		return max_books_to_loan;
	}
	
	public void setMax_books_to_loan(int max_books_to_loan) {
		this.max_books_to_loan = max_books_to_loan;
	}
	
	
	//Getter για το Fine Code του Student (αν έχει) με σκοπό την δημιουργεία column στο PaymentSceneCreator
	public String getFineCodes() {
	    List<String> codes = new ArrayList<>();
	    for (Fine fine : App.fines) {
	        if (fine.getLoan().getStudent().equals(this)) {
	            codes.add(String.valueOf(fine.getFineCode()));
	        }
	    }
	    return String.join(", ", codes);
	}

}
