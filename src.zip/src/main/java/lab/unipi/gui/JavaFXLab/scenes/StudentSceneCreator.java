package lab.unipi.gui.JavaFXLab.scenes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import lab.unipi.gui.JavaFXLab.App;
import lab.unipi.gui.JavaFXLab.Loan;
import lab.unipi.gui.JavaFXLab.Student;
import java.util.List;
import java.util.ArrayList;
import lab.unipi.gui.JavaFXLab.Loan;


public class StudentSceneCreator extends SceneCreator implements EventHandler<MouseEvent>{
  
	 	private TableView<Student>studentTableView;
	 	private TableView<Loan>loanTableView;
	 	//private List<Student>studentList;
	 	
	 	private TextField codeField , nameField , surnameField , birth_dateField , phoneField , emailField , amField , departmentField , max_books_to_loanField;
	 	private Button newStudentBtn , updateStudentBtn , loanHistoryBtn , backBtn;
	 	
	 	private GridPane inputFieldsPane , rootGridPane;
	 	private FlowPane buttonFlowPane;
	 	
	 	public StudentSceneCreator(double width , double height) {
	 		
	 		super(width , height);
	 		
	 		//1.Λιστα Δεδομενων
	 	   // studentList = new ArrayList<>();
	 	    studentTableView = new TableView<>();
	 	    loanTableView = new TableView<>();
	 	    
	 	    TableColumn<Student , Integer>codeCol = new TableColumn<>("Code");
	 	    codeCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("code"));
	 	    
	 	    TableColumn<Student , String>nameCol = new TableColumn<>("Name");
	 	    nameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));
	 	    
	 	    TableColumn<Student , String>surnameCol = new TableColumn<>("Surname");
	 	    surnameCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("surname"));
	 	    
	 	    TableColumn<Student , String>birth_dateCol = new TableColumn<>("Birth Date ");
	 	    birth_dateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("birth_date"));
	 	   
	 	    TableColumn<Student , String>phoneCol = new TableColumn<>("Phone");
	 	    phoneCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("phone"));
	 	    
	 	    TableColumn<Student , String>emailCol = new TableColumn<>("Email");
	 	    emailCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("email"));
	 	    
	 	    TableColumn<Student , String>amCol = new TableColumn<>("Am");
	 	    amCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("am"));
	 	    
	 	    TableColumn<Student , String>tmima_foithshsCol = new TableColumn<>("Department of Studies");
	 	    tmima_foithshsCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("department"));
	 	    
	 	    TableColumn<Student , Integer>max_books_to_loanCol = new TableColumn<>("Maximum Books");
	 	    max_books_to_loanCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("max_books_to_loan"));
	 	    
	 	   
	 	    studentTableView.getColumns().addAll(codeCol , nameCol , surnameCol , birth_dateCol , phoneCol ,  emailCol , amCol , tmima_foithshsCol , max_books_to_loanCol);
	 	    
	 	    
	 	   TableColumn<Loan, Integer> loanidCol = new TableColumn<>("Loan ID");
			loanidCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("loanId"));
			
			TableColumn<Loan, String> studentCol = new TableColumn<>("Student");
			studentCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("studentName"));
			
			TableColumn<Loan, String> bookCol = new TableColumn< >("Book");
	        bookCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("bookTitle"));

	        TableColumn<Loan, String> loanDateCol = new TableColumn<>("Loan Date");
	        loanDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("loanDate"));

	        TableColumn<Loan, String> dueDateCol = new TableColumn<>("Due Date");
	        dueDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("dueDate"));

	        TableColumn<Loan, String> returnDateCol = new TableColumn<>("Return Date");
	        returnDateCol.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("returnDate"));
	 	   
	        loanTableView.getColumns().addAll(loanidCol, studentCol, bookCol, loanDateCol, dueDateCol, returnDateCol);
	        
	        
	        //3.Πεδια
	 	    
	 	    codeField = new TextField(); codeField.setPromptText("Code");
	 	    nameField = new TextField(); nameField.setPromptText("Name");
	 	    surnameField = new TextField(); surnameField.setPromptText("Surname");
	 	    birth_dateField = new TextField(); birth_dateField.setPromptText("Birth Date");
	 	    phoneField = new TextField(); phoneField.setPromptText("Phone");
	 	    emailField = new TextField(); emailField.setPromptText("Email");
	 	    amField = new TextField(); amField.setPromptText("Am");
	 	    departmentField = new TextField(); departmentField.setPromptText("Department of Studies");
	 	  //  max_books_to_loanField = new TextField(); max_books_to_loanField.setPromptText("Maximum Books");
	 	    
	 	    //4.Buttons
	 	    newStudentBtn = new Button("New Student");
	 	    updateStudentBtn = new Button("Update Info");
	 	    loanHistoryBtn = new Button("Loan History");
	 	    backBtn = new Button("Back");
	 	    
	 	    //5.Input GripPane
	 	    
	 	    inputFieldsPane = new GridPane();
	 	    inputFieldsPane.setHgap(10);
	 	    inputFieldsPane.setVgap(10);
	 	    
	 	    inputFieldsPane.add(new Label("Code"), 0, 0);
	 	    inputFieldsPane.add(codeField, 1, 0);
	 	    
	 	    inputFieldsPane.add(new Label("Name :"), 0 ,1);
	 	    inputFieldsPane.add(nameField , 1 ,1);
	 	    
	 	    inputFieldsPane.add(new Label("Surname :"), 0 , 2);
	 	    inputFieldsPane.add(surnameField, 1, 2);
	 	    
	 	    inputFieldsPane.add(new Label("birth_date : "), 0, 3);
	 	    inputFieldsPane.add(birth_dateField, 1 , 3);
	 	    
	 	    inputFieldsPane.add(new Label("Phone"), 0, 4);
	 	    inputFieldsPane.add(phoneField, 1, 4);
	 	    
	 	    inputFieldsPane.add(new Label("Email : "), 0, 5);
	 	    inputFieldsPane.add(emailField, 1, 5);
	 	    
	 	    inputFieldsPane.add(new Label("Am :"), 0, 6);
	 	    inputFieldsPane.add(amField, 1, 6);
	 	    
	 	    inputFieldsPane.add(new Label("Department of Studies"), 0, 7);
	 	    inputFieldsPane.add(departmentField, 1, 7);
	 	    
	 	//    inputFieldsPane.add(new Label("Maximum Books"), 0, 8);
	 	 //   inputFieldsPane.add(max_books_to_loanField, 1, 8);
	 	    
	 	    //6.Buttons FlowPane
	 	    
	 	    buttonFlowPane = new FlowPane(10 , 10);
	 	    buttonFlowPane.setHgap(10);
	 	    buttonFlowPane.getChildren().addAll(newStudentBtn , updateStudentBtn , loanHistoryBtn , backBtn);
	 	    
	 	    //7.rootGridPane
	 	    
	 	    rootGridPane = new GridPane();
	 	    rootGridPane.setHgap(10);
	 	    rootGridPane.setVgap(10);
	 	    
	 	   rootGridPane.add(studentTableView , 0 , 1);
           rootGridPane.add(loanTableView, 0 , 3);
           rootGridPane.add(inputFieldsPane , 1 ,1, 1, 3);
           rootGridPane.add(buttonFlowPane, 0 ,4);
           rootGridPane.add(new Label("Student List"), 0 , 0);
           rootGridPane.add(new Label("Loan History"), 0 , 2);
	 	    //8. Events
	 	    
	 	    newStudentBtn.setOnMouseClicked(this);
	 	    updateStudentBtn.setOnMouseClicked(this);
	 	    loanHistoryBtn.setOnMouseClicked(this);
	 	    backBtn.setOnMouseClicked(this);
	 	    studentTableView.setOnMouseClicked(this);
	 	 
	 	    tableSync();
	 	}
	 	
	 	@Override
	 	public Scene createScene() {
	 		
	 		
	 	  	return new Scene(rootGridPane , width , height);
	 	}
	 	
	 	@Override
	 	public void handle(MouseEvent event){
	 		if(event.getSource() == newStudentBtn) {
	 			
	 			int code;
	 			try {
	 		        code = Integer.parseInt(codeField.getText().trim());
	 		    } catch (NumberFormatException e) {
	 		        showAlert("Σφάλμα", "Το πεδίο 'Code' πρέπει να είναι αριθμός.");
	 		        return;
	 		    }
	 			String name = nameField.getText();
	 			String surname = surnameField.getText();
	 			String birth_date = birth_dateField.getText();
	 			String phone = phoneField.getText();
	 			String email = emailField.getText();
	 			String am = amField.getText();
	 			String department = departmentField.getText();
	 			int max_books_to_loan;
	 			try {
	 		        max_books_to_loan = Integer.parseInt(max_books_to_loanField.getText().trim());
	 		    } catch (NumberFormatException e) {
	 		        showAlert("Σφάλμα", "Το πεδίο 'Maximum Books' πρέπει να είναι αριθμός.");
	 		        return;
	 		    }
	 			
	 			createStudent(code, name, surname, birth_date, phone, email, am, department, max_books_to_loan);
	 			
	 			tableSync();
		 		clearTextFields();
		 		
	 		}else if(event.getSource() == updateStudentBtn) {
	 			
	 			int code;
	 			try {
	 		        code = Integer.parseInt(codeField.getText().trim());
	 		    } catch (NumberFormatException e) {
	 		        showAlert("Σφάλμα", "Το πεδίο 'Code' πρέπει να είναι αριθμός.");
	 		        return;
	 		    }
	 			String name = nameField.getText();
	 			String surname = surnameField.getText();
	 			String birth_date = birth_dateField.getText();
	 			String phone = phoneField.getText();
	 			String email = emailField.getText();
	 			String am = amField.getText();
	 			String department = departmentField.getText();
	 			int max_books_to_loan;
	 			try {
	 		        max_books_to_loan = Integer.parseInt(max_books_to_loanField.getText().trim());
	 		    } catch (NumberFormatException e) {
	 		        showAlert("Σφάλμα", "Το πεδίο 'Maximum Books' πρέπει να είναι αριθμός.");
	 		        return;
	 		    }
	 			
	 			updateStudent(code , name , surname, birth_date , phone , email , am , department, max_books_to_loan);
	 			
	 			tableSync();
	 			clearTextFields();
	 			
	 		}else if (event.getSource() == loanHistoryBtn) {
	 			
	 			Student selectedStudent = studentTableView.getSelectionModel().getSelectedItem();
	 			
	 			loanTableView.getItems().clear();
	 			 if (selectedStudent == null) {
	 		        Alert alert = new Alert(Alert.AlertType.WARNING);
	 		        alert.setTitle("No Student Selected");
	 		        alert.setHeaderText("No student selected from the table.");
	 		        alert.setContentText("Please select a student first to view their loan history.");
	 		        alert.showAndWait();
	 		        return;
	 		    }
	 			 
	 			for( Loan loan : App.loans) {
	 				if (loan.getStudent().getCode() == selectedStudent.getCode()) {
	 					loanTableView.getItems().add(loan);
	 				}
	 			}
	 			
	 		}else if(event.getSource() == backBtn) {
	 			App.primaryStage.setScene(App.mainScene);
	            App.primaryStage.setTitle("Main Window");
	 		}else if(event.getSource() == studentTableView) {
	 			  // Γέμισμα text fields με τα δεδομένα της επιλεγμένης γραμμής
	 		}	
	 		
	 		
	 	}	
	 	 
	 	public void clearTextFields() {
	 		
	 		codeField.setText("");
	 		nameField.setText("");
	 		surnameField.setText("");
	 		birth_dateField.setText("");
	 		phoneField.setText("");
	 		emailField.setText("");
	 		amField.setText("");
	 		departmentField.setText("");
	 		max_books_to_loanField.setText("");
	 		
	 	}
	 	
	 	public void tableSync() {
	 		
	 		studentTableView.getItems().clear();
	 		studentTableView.getItems().addAll(App.students);

        }
	 	
	 	//public void 
	 	
	 	public void createStudent(int code , String name, String surname , String birth_date , String phone , String email, String am, String department, int max_books_to_loan) {
	 		for (Student student : App.students) {
	 	        if (student.getCode() == code) {
	 	            showAlert("Σφάλμα", "Υπάρχει ήδη φοιτητής με τον κωδικό: " + code);
	 	            return;
	 	        }
	 	    }
	 		max_books_to_loan = 5;
	 		Student newStudent = new Student(code , name , surname , birth_date , phone , email , am , department , max_books_to_loan);
	 		App.students.add(newStudent);
	 		studentTableView.getItems().add(newStudent);
	 		
	 	}	
	 	
	 	public void updateStudent(int code , String name, String surname , String birth_date , String phone , String email, String am, String department, int max_books_to_loan) {
	 		
	 		for(Student newStudent : App.students) {
	 			
	 			 if(newStudent.getCode() == code) {

                     ((Student) newStudent).setName(name);
                     ((Student) newStudent).setSurname(surname);
                     ((Student) newStudent).setBirth_date(birth_date);
                     ((Student) newStudent).setPhone(phone);
                     ((Student) newStudent).setEmail(email);
                     ((Student) newStudent).setAm(am);
                     ((Student) newStudent).setDepartment(department);
                     newStudent.setMax_books_to_loan(max_books_to_loan);
                     return;

                 }
	 			 
	 			
	 		}
	 		showAlert("Σφάλμα", "Δεν βρέθηκε φοιτητής με τον κωδικό: " + code + " για ενημέρωση.");
	 	}
	 	private void showAlert(String title, String message) {
	 	    Alert alert = new Alert(Alert.AlertType.ERROR);
	 	    alert.setTitle(title);
	 	    alert.setHeaderText(null);
	 	    alert.setContentText(message);
	 	    alert.showAndWait();
	 	}
	 	
	 	
}

