package lab.unipi.gui.JavaFXLab;

import java.time.LocalDate;

public class Loan {
	
	private int loanId;
	private Student student;
	private Book book;
	private LocalDate loanDate;
	private LocalDate dueDate;
	private LocalDate returnDate;
	private boolean delay;
	private String status;
	
	public Loan (int loanId, Student student, Book book) {
		this.loanId = loanId;
		this.student = student;
		this.book = book;
		this.loanDate = LocalDate.now();
		this.dueDate = loanDate.plusDays(14);
		this.returnDate = null;
		this.delay = false;
		this.status = "Ενεργός";
	
	}
	
	
	//Getters & setters
	public int getLoanId() {
		return loanId;
	}
	
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	
	public String getStudentName() {
		return student.getName() + " " + student.getSurname();
	}
	
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public Book getBook() {
		return book;
	}
	
	public Student getStudent() {
		return student;
	}
	
	public String getBookTitle() {
	    return book.getTitle();
	}

	public void setTitle(Book book) {
	    this.book = book;
	}

	public LocalDate getLoanDate() {
	    return loanDate;
	}

	public void setLoanDate(LocalDate loanDate) {
	    this.loanDate = loanDate;
	}

	public LocalDate getDueDate() {
	    return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
	    this.dueDate = dueDate;
	}

	public LocalDate getReturnDate() {
	    return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
	    this.returnDate = returnDate;
	}

	public boolean getDelay() {
	    return delay;
	}

	public void setDelay(boolean delay) {
	    this.delay = delay;
	}

	public String getStatus() {
	    return status;
	}

	public void setStatus(String status) {
	    this.status = status;
	}
	
	public void updatedelay(LocalDate returnDate) {
		this.returnDate = returnDate;
		
		if (returnDate.isAfter(dueDate)) {
			this.delay = true;
			this.status = "Καθυστερημένος";
		} else {
			this.delay = false;
			this.status = "Ολοκληρωμένος";
		}
	}

}
