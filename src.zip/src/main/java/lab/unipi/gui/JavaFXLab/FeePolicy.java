package lab.unipi.gui.JavaFXLab;

public interface FeePolicy {
	
	double calculateFine(int overdueDays);

}
