package lab.unipi.gui.JavaFXLab;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lab.unipi.gui.JavaFXLab.scenes.SceneCreator;
import lab.unipi.gui.JavaFXLab.scenes.MainSceneCreator;
import lab.unipi.gui.JavaFXLab.scenes.BookSceneCreator;
import lab.unipi.gui.JavaFXLab.scenes.StudentSceneCreator;
import lab.unipi.gui.JavaFXLab.scenes.LoanSceneCreator;
import lab.unipi.gui.JavaFXLab.scenes.PaymentSceneCreator;

public class App extends Application {
	
	public static List<Book> books = new ArrayList<>();
	public static List<Student> students = new ArrayList<>();
    public static List<Loan> loans = new ArrayList<>();
    public static List<Fine> fines = new ArrayList<>();
    
    public static Stage primaryStage;
    public static Scene mainScene, bookScene, studentScene, loanScene, fineScene;

    @Override
    public void start(Stage primaryStage) {
        
        //10 Παραδείγματα Βιβλίων:
    	App.books.add(new Book("123-456-789-1", "To kill a mockingbird", "Harper Lee", "Penguin Random House", 1960, "Fiction", true));
    	App.books.add(new Book("123-456-789-2", "1984", "George Orwell", "Harper Collins", 1949, "Dystopian", true));
    	App.books.add(new Book("123-456-789-3", "The Lord of the Rings", "J.R.R. Tolkien", "Simon and Schuster", 1954, "Fantasy", true));
    	App.books.add(new Book("123-456-789-4", "The Great Gatsby", "F. Scott Fitzgerald", "Macmillan Publishers", 1925, "Classic", true));
    	App.books.add(new Book("123-456-789-5", "Brave New World", "Aldous Huxley", "Hachette Book Group", 1932, "Science Fiction", true));
    	App.books.add(new Book("123-456-789-6", "Pride and Prejudice", "Jane Austen", "John Wiley and Sons", 1813, "Romance", true));
    	App.books.add(new Book("123-456-789-7", "The Catcher in the Rye", "J.D. Salinger", "Merriam-Webster", 1951, "Fiction", true));
    	App.books.add(new Book("123-456-789-8", "Jane Eyre", "Charlotte Brontë", "Scholastic ", 1847, "Classic", true));
    	App.books.add(new Book("123-456-789-9", "The Alchemist", "Paulo Coelho", "Pearson", 1988, "Philosophical", true));
    	App.books.add(new Book("123-456-789-0", "Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "Houghton Mifflin Harcourt", 1997, "Fantasy", true));
       
    	//5 παραδείγματα φοιτητών:
    	App.students.add(new Student(1, "Kostis", "Tassis", "10-05-2006", "6948392203", "kostis@unipi.com", "E12345", "Digital Systems", 5));
    	App.students.add(new Student(2, "Aggelos", "Karahalis", "15-09-2006", "6920394219", "aggelos@unipi.com", "E23456", "Physics", 5));
    	App.students.add(new Student(3, "Maria", "Papadopoulou", "12-04-2000", "6941234567", "maria@unipi.com", "E34567", "Informatics", 5));
    	App.students.add(new Student(4, "Dimitris", "Giannakakis", "05-08-2000", "6909876543", "dimitris@unipi.com", "E45678", "Electrical Engineering", 5));
    	App.students.add(new Student(5, "Giorgos", "Nikolaidis", "30-08-1998", "6987654321", "giorgos@unipi.com", "E67890", "Chemistry", 5));
    	
    	//Δοκιμαστικό Loan με αργοπορία 1 μέρα για δοκιμή των λειτουργιών του PaymentSceneCreator
    	
    	Loan loan1 = new Loan(1, App.students.get(0), App.books.get(0));
    	loan1.updatedelay(LocalDate.now().plusDays(15)); //1 μερα μετά το duedate
    	App.loans.add(loan1);

    	Fine fine1 = new Fine(101, loan1); 
    	App.fines.add(fine1);
    	
    	
    	this.primaryStage = primaryStage;
        
    	
    	//Δημιουργία Σκηνών
    	
    	//main
        SceneCreator mainSceneCreator = new MainSceneCreator(700, 350);
        mainScene = mainSceneCreator.createScene();
        
        //Book
        SceneCreator bookSceneCreator = new BookSceneCreator(700, 350);
        bookScene = bookSceneCreator.createScene();
         
        //Student
        SceneCreator studentSceneCreator = new StudentSceneCreator(700, 350);
        studentScene = studentSceneCreator.createScene();
       
        //Loan
        SceneCreator loanSceneCreator = new LoanSceneCreator(700,350);
        loanScene = loanSceneCreator.createScene();
        
        //Fine
        SceneCreator fineSceneCreator = new PaymentSceneCreator(700,350);
        fineScene = fineSceneCreator.createScene();
        
        
        primaryStage.setScene(mainScene);
        primaryStage.setTitle("Main Window");
        primaryStage.show();
        
    }

    public static void main(String[] args) {
        launch();
    }
    

}