module lab.unipi.gui.JavaFXLab {
    requires javafx.controls;
    exports lab.unipi.gui.JavaFXLab;
}
